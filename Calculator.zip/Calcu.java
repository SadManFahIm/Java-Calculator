import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class Calcu extends JFrame implements ActionListener
{
	JLabel   title, p1, p2, imgLabel;
	JButton off, back, l1, l2, l3, l4, l5, l6, l7, l8, l9, l0, ld, le, ldiv, lmulti, lsub, ladd, lc, lac, mp, mm, mc, mr, history, chistory;
	JPanel panel;
	ImageIcon img;
	String x="", s, f, temp;
	double d1, d2, d, r;
	boolean repeat=false, mrepeat=false, equal=false, rle=false;
	File file = new File("m.txt");
	
	public Calcu(File file, boolean mrepeat)
	{
		super("Calculator");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(388, 575);
		
		this.file=file;
		this.mrepeat=mrepeat;
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.WHITE);
		
		
		title = new JLabel(x);
		title.setBounds(20,20,350,50);
		title.setBackground(Color.WHITE);
		title.setForeground(Color.black);
		title.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,30));
		title.setOpaque(true);
		panel.add(title);
		
		mp = new JButton("M+");
		mp.setBounds(20,180,50,50);
		mp.setBackground(Color.BLUE);
		mp.setForeground(Color.white);
		mp.addActionListener(this);
		mp.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,15));
		panel.add(mp);
		
		mm = new JButton("M-");
		mm.setBounds(20,250,50,50);
		mm.setBackground(Color.BLUE);
		mm.setForeground(Color.white);
		mm.addActionListener(this);
		mm.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,15));
		panel.add(mm);
		
		mc = new JButton("MC");
		mc.setBounds(20,320,50,50);
		mc.setBackground(Color.BLUE);
		mc.setForeground(Color.white);
		mc.addActionListener(this);
		mc.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,15));
		panel.add(mc);
		
		mr = new JButton("MR");
		mr.setBounds(20,390,50,50);
		mr.setBackground(Color.BLUE);
		mr.setForeground(Color.white);
		mr.addActionListener(this);
		mr.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,15));
		panel.add(mr);
		
		history = new JButton("History");
		history.setBounds(20,460,120,50);
		history.setBackground(Color.YELLOW);
		history.setForeground(Color.black);
		history.addActionListener(this);
		history.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,15));
		panel.add(history);
		
		chistory = new JButton("Clear History");
		chistory.setBounds(160,460,190,50);
		chistory.setBackground(Color.YELLOW);
		chistory.setForeground(Color.black);
		chistory.addActionListener(this);
		chistory.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,15));
		panel.add(chistory);

		off = new JButton("OFF");
		off.setBounds(20, 110, 120, 50);
		off.setBackground(Color.RED);
		off.addActionListener(this);
		off.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(off);
		
		lac = new JButton("AC");
		lac.setBounds(160,110,120,50);
		lac.addActionListener(this);
		lac.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(lac);
		
		lc = new JButton("<");
		lc.setBounds(300,110,50,50);
		lc.addActionListener(this);
		lc.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(lc);
		
		
		l7 = new JButton("7");
		l7.setBounds(90,180,50,50);
		l7.addActionListener(this);
		l7.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(l7);
		
		l8= new JButton("8");
		l8.setBounds(160,180,50,50);
		l8.addActionListener(this);
		l8.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(l8);
		
		l9 = new JButton("9");
		l9.setBounds(230,180,50,50);
		l9.addActionListener(this);
		l9.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(l9);
		
		ldiv = new JButton("/");
		ldiv.setBounds(300,180,50,50);
		ldiv.setBackground(Color.GREEN);
		ldiv.addActionListener(this);
		ldiv.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(ldiv);

		l4 = new JButton("4");
		l4.setBounds(90,250,50,50);
		l4.addActionListener(this);
		l4.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(l4);
		
		l5 = new JButton("5");
		l5.setBounds(160,250,50,50);
		l5.addActionListener(this);
		l5.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(l5);
		
		l6 = new JButton("6");
		l6.setBounds(230,250,50,50);
		l6.addActionListener(this);
		l6.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(l6);
		
		lmulti = new JButton("*");
		lmulti.setBounds(300,250,50,50);
		lmulti.setBackground(Color.GREEN);
		lmulti.addActionListener(this);
		lmulti.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(lmulti);
		
		l1 = new JButton("1");
		l1.setBounds(90,320,50,50);
		l1.addActionListener(this);
		l1.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(l1);
		
		l2 = new JButton("2");
		l2.setBounds(160,320,50,50);
		l2.addActionListener(this);
		l2.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(l2);
		
		l3 = new JButton("3");
		l3.setBounds(230,320,50,50);
		l3.addActionListener(this);
		l3.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(l3);
		
		lsub = new JButton("-");
		lsub.setBounds(300,320,50,50);
		lsub.setBackground(Color.GREEN);
		lsub.addActionListener(this);
		lsub.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(lsub);
		
		
		l0 = new JButton("0");
		l0.setBounds(90,390,50,50);
		l0.addActionListener(this);
		l0.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(l0);
		
		ld = new JButton(".");
		ld.setBounds(160,390,50,50);
		ld.addActionListener(this);
		ld.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(ld);
		
		le = new JButton("=");
		le.setBounds(230,390,50,50);
		le.addActionListener(this);
		le.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(le);
		
		ladd= new JButton("+");
		ladd.setBounds(300,390,50,50);
		ladd.setBackground(Color.GREEN);
		ladd.addActionListener(this);
		ladd.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,20));
		panel.add(ladd);
		
		
		
		
		this.add(panel);
	}
	
	
	public void history(String n)
	{
		try
		{
			File filew = new File("history.txt");
			FileReader reader = new FileReader(filew);
			BufferedReader bfl = new BufferedReader(reader);
	
			String a="";
			while((temp=bfl.readLine())!=null)
				{
					a=a+temp+"\r"+"\n";
				}

			f=a+n+"\r"+"\n";
			FileWriter writer = new FileWriter(filew); 
			writer.write(f); 
			writer.flush();
			writer.close();
		}
		catch(Exception e){}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String elementText = ae.getActionCommand();
		
		
		if(elementText.equals(l0.getText()))
			{
				if(equal==true)
					{x="";x=x+"0.";title.setText(x);equal=false;}
				else
					{
						if(x=="")
							{x=x+"0.";title.setText(x);}
						else
							{x=x+"0";title.setText(x);}
					}
			}
		
		
		
		else if(elementText.equals(ld.getText()))
			{
				if(equal==true)
					{
						x="";x="0.";title.setText(x);equal=false;
					}
				else
					{
						if(title.getText()=="")
							{x="0.";title.setText(x);}
						else
							{x=x+".";title.setText(x);}
					}
				
			}
			
			
			
		else if(elementText.equals(le.getText()))
			{
				String sdf=null, sdn=null;
				if(repeat==true)
				{
					if(s=="+")
						{sdn=Double.toString(d);d=d+d2;sdf=Double.toString(d);rle=true;}
					else if(s=="-")
						{sdn=Double.toString(d);d=d-d2;sdf=Double.toString(d);rle=true;}
					else if(s=="*")
						{sdn=Double.toString(d);d=d*d2;sdf=Double.toString(d);rle=true;}
					else if(s=="/")
						{sdn=Double.toString(d);d=d/d2;sdf=Double.toString(d);rle=true;}
				}
				else
				{
					d2=Double.parseDouble(x);
					if(s=="+")
						{d=d1+d2;repeat=true;sdf=Double.toString(d);}
					else if(s=="-")
						{d=d1-d2;repeat=true;sdf=Double.toString(d);}
					else if(s=="*")
						{d=d1*d2;repeat=true;sdf=Double.toString(d);}
					else if(s=="/")
						{d=d1/d2;repeat=true;sdf=Double.toString(d);}
				}
				
				x=Double.toString(d);
				title.setText(x);
				equal=true;
				//x="";
				try
					{
						String sd1, sd2;
						sd1=Double.toString(d1);
						sd2=Double.toString(d2);

						File filew = new File("history.txt");
						FileReader reader = new FileReader(filew);
						BufferedReader bfl = new BufferedReader(reader);
						
						String a="";
						while((temp=bfl.readLine())!=null)
							{
								a=a+temp+"\r"+"\n";
							}
							
						if(rle==true)
							{f=a+sdn+"  "+s+"  "+sd2+"  =  "+sdf+"\r"+"\n";rle=false;}
						else
							{f=a+sd1+"  "+s+"  "+sd2+"  =  "+sdf+"\r"+"\n";}
						FileWriter writer = new FileWriter(filew); 
						writer.write(f); 
						writer.flush();
						writer.close();
					}	
					catch(Exception e){}
			}
			
			
			
		else if(elementText.equals(l1.getText()))
			{
				if(equal==true)
					{x="";x=x+"1";title.setText(x);equal=false;}
				else
					{x=x+"1";title.setText(x);}
			}
		else if(elementText.equals(l2.getText()))
			{
				if(equal==true)
					{x="";x=x+"2";title.setText(x);equal=false;}
				else
					{x=x+"2";title.setText(x);}
			}
		else if(elementText.equals(l3.getText()))
			{
				if(equal==true)
					{x="";x=x+"3";title.setText(x);equal=false;}
				else
					{x=x+"3";title.setText(x);}
			}
		else if(elementText.equals(l4.getText()))
			{
				if(equal==true)
					{x="";x=x+"4";title.setText(x);equal=false;}
				else
					{x=x+"4";title.setText(x);}
			}
		else if(elementText.equals(l5.getText()))
			{
				if(equal==true)
					{x="";x=x+"5";title.setText(x);equal=false;}
				else
					{x=x+"5";title.setText(x);}
			}
		else if(elementText.equals(l6.getText()))
			{
				if(equal==true)
					{x="";x=x+"6";title.setText(x);equal=false;}
				else
					{x=x+"6";title.setText(x);}
			}
		else if(elementText.equals(l7.getText()))
			{
				if(equal==true)
					{x="";x=x+"7";title.setText(x);equal=false;}
				else
					{x=x+"7";title.setText(x);}
			}
		else if(elementText.equals(l8.getText()))
			{
				if(equal==true)
					{x="";x=x+"8";title.setText(x);equal=false;}
				else
					{x=x+"8";title.setText(x);}
			}
		else if(elementText.equals(l9.getText()))
			{
				if(equal==true)
					{x="";x=x+"9";title.setText(x);equal=false;}
				else
					{x=x+"9";title.setText(x);}
			}
		
		
		
		else if(elementText.equals(ladd.getText()))
			{
				if(x==""){}
				else
				{
					repeat=false; s=""; 
					d1=Double.parseDouble(x);
					x=""; s="+"; title.setText(s);
				}
			}
		else if(elementText.equals(lsub.getText()))
			{
				if(x==""){}
				else
				{
					repeat=false; s=""; d1=Double.parseDouble(x); x=""; s="-"; title.setText(s);
				}
			}
		else if(elementText.equals(lmulti.getText()))
			{
				if(x==""){}
				else
				{
					repeat=false; s=""; d1=Double.parseDouble(x); x=""; s="*"; title.setText(s);
				}
			}
		else if(elementText.equals(ldiv.getText()))
			{
				if(x==""){}
				else
				{
					repeat=false; s=""; d1=Double.parseDouble(x); x=""; s="/"; title.setText(s);
				}
			}
			
			
			
		else if(elementText.equals(mp.getText()))
			{
				try
				{
					if(mrepeat==true)
						{
							try
								{
									FileReader reader = new FileReader(file);
									BufferedReader bfl = new BufferedReader(reader);
									f=bfl.readLine();
									reader.close();
									d1=Double.parseDouble(f);
									d2=Double.parseDouble(title.getText());
									d=d1+d2;
									f=Double.toString(d);
									FileWriter writer = new FileWriter(file); 
									writer.write(f); 
									writer.flush();
									writer.close();
									
									temp="M+ : "+f;
									history(temp);
								}	
								catch(Exception e){}
						}
					else
						{
							f=title.getText();
							FileWriter writer = new FileWriter(file); 
							writer.write(f); 
							writer.flush();
							writer.close();
							mrepeat=true;
							
							temp="M+ : "+f;
							history(temp);
						}
					
					f="";
				}
				catch(Exception e){}
				equal=true;
			}
		else if(elementText.equals(mm.getText()))
			{
				try
				{
					if(mrepeat==true)
						{
							try
								{
									FileReader reader = new FileReader(file);
									BufferedReader bfl = new BufferedReader(reader);
									f=bfl.readLine();
									reader.close();
									d1=Double.parseDouble(f);
									d2=Double.parseDouble(title.getText());
									d=d1-d2;
									f=Double.toString(d);
									FileWriter writer = new FileWriter(file); 
									writer.write(f); 
									writer.flush();
									writer.close();
									
									temp="M- : "+f;
									history(temp);
								}	
								catch(Exception e){}
						}
					else
						{}
					
					f="";
				}
				catch(Exception e){}
				equal=true;
			}
		else if(elementText.equals(mc.getText()))
			{
				try
				{
					f="0";
					FileWriter writer = new FileWriter(file); 
					writer.write(f); 
					writer.flush();
					writer.close();
					
					temp="M Cancel";
					history(temp);
					
					f="";
					mrepeat=false;
				}
				catch(Exception e){}
			}
		else if(elementText.equals(mr.getText()))
			{
				try
				{
					FileReader reader = new FileReader(file);
					BufferedReader bfl = new BufferedReader(reader);
					x=bfl.readLine();
					title.setText(x);
					reader.close();
					
					temp="M recalled : "+x;
					history(temp);
				}
				catch(Exception e){}
				equal=true;
			}
			
			
			
		else if(elementText.equals(lc.getText()))
			{x=x.replaceFirst(".$","");title.setText(x);}
		
		else if(elementText.equals(lac.getText()))
			{x="";title.setText(x);}
		else if(elementText.equals(history.getText()))
			{
				History h = new History(mrepeat);
				h.setVisible(true);
				this.setVisible(false);
			}
		else if(elementText.equals(chistory.getText()))
			{
				try
				{
					File filew = new File("history.txt");
					FileReader reader = new FileReader(filew);
					BufferedReader bfl = new BufferedReader(reader);
	
					String a="";

					FileWriter writer = new FileWriter(filew); 
					writer.write(a); 
					writer.flush();
					writer.close();
				}
				catch(Exception e){}
			}
		
		if(elementText.equals(off.getText()))
		{
			System.exit(0);
		}else{}
	}	
}