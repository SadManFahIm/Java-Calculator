import  java.lang.*;
import  javax.swing.*;
import  java.awt.*;
import  java.awt.event.*;
import  java.io.*;
import  java.util.*;
import  javax.swing.table.*;


public  class  History  extends  JFrame  implements ActionListener
{
	private JTable contactTable;
	private JScrollPane tableScrollPane;
	private JButton back;
	private JPanel panel;
	boolean mrepeat;
	File file = new File("m.txt");
	
	public History(boolean mrepeat)
	{
		super("Calculator operation history");
		this.setSize(389, 580);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.mrepeat=mrepeat;
		
		panel = new JPanel();
		panel.setLayout(null);
		
		back = new JButton("Back");
		back.setBounds(135,450,100,50);
		back.addActionListener(this);
		back.setFont(new Font("Consolas",Font.ITALIC+Font.BOLD,15));
		panel.add(back);
		
		String columns[] =  {"History"};
		JTable contactTable = new JTable();
		DefaultTableModel tableModel;
    // specify number of columns
		tableModel = new DefaultTableModel(0,2); 
		tableModel.setColumnIdentifiers(columns);
		contactTable.setModel(tableModel);
		tableScrollPane = new JScrollPane(contactTable);
		tableScrollPane.setBounds(11,10,350,400);
		panel.add(tableScrollPane);
		
		
		String temp; 
		try
		{
			File file = new File("history.txt");
			FileReader reader = new FileReader(file);
			BufferedReader bfl = new BufferedReader(reader);
		
		
			while((temp=bfl.readLine())!=null)
			{
				tableModel.addRow(temp.split(", "));
			}
		  
			reader.close();
		}
		catch(Exception e){}
		
		
		this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String elementText = ae.getActionCommand();
		
		
		if(elementText.equals(back.getText()))
			{
				Calcu c = new Calcu(file,mrepeat);
				c.setVisible(true);
				this.setVisible(false);
			}
	
	}


}