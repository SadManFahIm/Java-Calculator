import java.io.*;

public class Start
{
	public static void main(String args[]) throws Exception
	{
		boolean mrepeat=false;
		File file = new File("m.txt");
		file.createNewFile();
		File filew = new File("history.txt");
		filew.createNewFile();
		Calcu c = new Calcu(file,mrepeat);
		c.setVisible(true);

	}
}